document.addEventListener('DOMContentLoaded', function() {
    var addFavoriteForm = document.getElementById('add-favorite-form');
    var favoritesList = document.getElementById('favorites-list');
});

    